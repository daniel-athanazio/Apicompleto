package br.com.ericksteams.desafio5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Desafio5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
